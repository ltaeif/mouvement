<?php

/**
 * Row definition class for table files.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Files_Row extends Application_Model_Files_Row_Abstract
{
    // write your custom functions here
}
