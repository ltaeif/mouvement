<?php

/**
 * Rowset definition class for table ville.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Ville_Rowset extends Application_Model_Ville_Rowset_Abstract
{
    // write your custom functions here
}
