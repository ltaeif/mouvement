<?php

/**
 * Row definition class for table ville.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Ville_Row extends Application_Model_Ville_Row_Abstract
{
    // write your custom functions here
}
