<?php

/**
 * Definition class for table ville.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Ville_DbTable extends Application_Model_Ville_DbTable_Abstract
{
    // write your custom functions here
}