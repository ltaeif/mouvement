<?php

/**
 * Definition class for table parcours.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Parcours_DbTable extends Application_Model_Parcours_DbTable_Abstract
{
    // write your custom functions here
}