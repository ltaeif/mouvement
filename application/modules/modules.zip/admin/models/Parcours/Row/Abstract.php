<?php

/**
 * Row definition class for table parcours.
 *
 * Do NOT write anything in this file, it will be removed when you regenerated.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 * @method Application_Model_Parcours_Row setFromArray($data)
 *
 * @property integer $id
 * @property string $code
 * @property string $niveau
 * @property string $diplome
 * @property string $specialite
 * @property string $codeetab
 */
abstract class Application_Model_Parcours_Row_Abstract extends Zend_Db_Table_Row_Abstract
{
    /**
     * Set value for 'id' field
     *
     * @param integer $Id
     *
     * @return Application_Model_Parcours_Row
     */
    public function setId($Id)
    {
        $this->id = $Id;
        return $this;
    }

    /**
     * Get value of 'id' field
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value for 'code' field
     *
     * @param string $Code
     *
     * @return Application_Model_Parcours_Row
     */
    public function setCode($Code)
    {
        $this->code = $Code;
        return $this;
    }

    /**
     * Get value of 'code' field
     *
     * @return string
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set value for 'niveau' field
     *
     * @param string $Niveau
     *
     * @return Application_Model_Parcours_Row
     */
    public function setNiveau($Niveau)
    {
        $this->niveau = $Niveau;
        return $this;
    }

    /**
     * Get value of 'niveau' field
     *
     * @return string
     */
    public function getNiveau()
    {
        return $this->niveau;
    }

    /**
     * Set value for 'diplome' field
     *
     * @param string $Diplome
     *
     * @return Application_Model_Parcours_Row
     */
    public function setDiplome($Diplome)
    {
        $this->diplome = $Diplome;
        return $this;
    }

    /**
     * Get value of 'diplome' field
     *
     * @return string
     */
    public function getDiplome()
    {
        return $this->diplome;
    }

    /**
     * Set value for 'specialite' field
     *
     * @param string $Specialite
     *
     * @return Application_Model_Parcours_Row
     */
    public function setSpecialite($Specialite)
    {
        $this->specialite = $Specialite;
        return $this;
    }

    /**
     * Get value of 'specialite' field
     *
     * @return string
     */
    public function getSpecialite()
    {
        return $this->specialite;
    }

    /**
     * Set value for 'codeetab' field
     *
     * @param string $Codeetab
     *
     * @return Application_Model_Parcours_Row
     */
    public function setCodeetab($Codeetab)
    {
        $this->codeetab = $Codeetab;
        return $this;
    }

    /**
     * Get value of 'codeetab' field
     *
     * @return string
     */
    public function getCodeetab()
    {
        return $this->codeetab;
    }

    /**
     * Get a row of Etablissement.
     *
     * @return Application_Model_Etablissement_Row
     */
    public function getEtablissementRowByCodeetab()
    {
        return $this->findParentRow('Application_Model_Etablissement_DbTable', 'codeetab');
    }

    /**
     * Get a list of rows of Chparcours.
     *
     * @return Application_Model_Chparcours_Rowset
     */
    public function getChparcoursRowsBySectionActuelle()
    {
        return $this->findDependentRowset('Application_Model_Chparcours_DbTable', 'section_actuelle');
    }

    /**
     * Get a list of rows of Chparcours.
     *
     * @return Application_Model_Chparcours_Rowset
     */
    public function getChparcoursRowsBySectionDemande()
    {
        return $this->findDependentRowset('Application_Model_Chparcours_DbTable', 'section_demande');
    }

    /**
     * Get a list of rows of Mutation.
     *
     * @return Application_Model_Mutation_Rowset
     */
    public function getMutationRowsBySectionDemande()
    {
        return $this->findDependentRowset('Application_Model_Mutation_DbTable', 'section_demande');
    }

    /**
     * Get a list of rows of Reorientation.
     *
     * @return Application_Model_Reorientation_Rowset
     */
    public function getReorientationRowsBySectionDemande()
    {
        return $this->findDependentRowset('Application_Model_Reorientation_DbTable', 'section_demande');
    }

    /**
     * Get a list of rows of Report.
     *
     * @return Application_Model_Report_Rowset
     */
    public function getReportRowsBySectionActuelle()
    {
        return $this->findDependentRowset('Application_Model_Report_DbTable', 'section_actuelle');
    }
    
    /**
     * Get the label that has been auto-detected by Zodeken
     *
     * @return string
     */
    public function getZodekenAutoLabel()
    {
        return $this->code;
    }
}
