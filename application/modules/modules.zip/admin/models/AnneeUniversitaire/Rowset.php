<?php

/**
 * Rowset definition class for table annee_universitaire.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_AnneeUniversitaire_Rowset extends Application_Model_AnneeUniversitaire_Rowset_Abstract
{
    // write your custom functions here
}
