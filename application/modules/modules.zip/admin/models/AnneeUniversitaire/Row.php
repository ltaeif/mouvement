<?php

/**
 * Row definition class for table annee_universitaire.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_AnneeUniversitaire_Row extends Application_Model_AnneeUniversitaire_Row_Abstract
{
    // write your custom functions here
}
