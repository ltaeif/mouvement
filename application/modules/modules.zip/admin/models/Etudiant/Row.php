<?php

/**
 * Row definition class for table etudiant.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Etudiant_Row extends Application_Model_Etudiant_Row_Abstract
{
    // write your custom functions here
}
