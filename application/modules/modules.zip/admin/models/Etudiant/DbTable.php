<?php

/**
 * Definition class for table etudiant.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Etudiant_DbTable extends Application_Model_Etudiant_DbTable_Abstract
{
    // write your custom functions here
}