<?php

/**
 * Rowset definition class for table report.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Report_Rowset extends Application_Model_Report_Rowset_Abstract
{
    // write your custom functions here
}
