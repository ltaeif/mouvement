<?php

/**
 * Row definition class for table report.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Report_Row extends Application_Model_Report_Row_Abstract
{
    // write your custom functions here
}
