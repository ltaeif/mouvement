<?php

/**
 * Rowset definition class for table inscription.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Inscription_Rowset extends Application_Model_Inscription_Rowset_Abstract
{
    // write your custom functions here
}
