<?php

/**
 * Row definition class for table inscription.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Inscription_Row extends Application_Model_Inscription_Row_Abstract
{
    // write your custom functions here
}
