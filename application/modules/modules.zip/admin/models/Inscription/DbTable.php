<?php

/**
 * Definition class for table inscription.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Inscription_DbTable extends Application_Model_Inscription_DbTable_Abstract
{
    // write your custom functions here
}