<?php

/**
 * Definition class for table etablissement.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Etablissement_DbTable extends Application_Model_Etablissement_DbTable_Abstract
{
    // write your custom functions here
}