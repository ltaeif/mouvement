<?php

/**
 * Rowset definition class for table etablissement.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Etablissement_Rowset extends Application_Model_Etablissement_Rowset_Abstract
{
    // write your custom functions here
}
