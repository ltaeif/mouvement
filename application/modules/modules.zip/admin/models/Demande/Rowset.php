<?php

/**
 * Rowset definition class for table demande.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Demande_Rowset extends Application_Model_Demande_Rowset_Abstract
{
    // write your custom functions here
}
