<?php

/**
 * Definition class for table demande.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Demande_DbTable extends Application_Model_Demande_DbTable_Abstract
{
    // write your custom functions here
}