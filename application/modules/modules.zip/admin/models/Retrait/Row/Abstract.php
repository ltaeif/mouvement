<?php

/**
 * Row definition class for table retrait.
 *
 * Do NOT write anything in this file, it will be removed when you regenerated.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 * @method Application_Model_Retrait_Row setFromArray($data)
 *
 * @property integer $codedem
 * @property string $cause
 * @property string $attestation_affectation
 */
abstract class Application_Model_Retrait_Row_Abstract extends Zend_Db_Table_Row_Abstract
{
    /**
     * Set value for 'codedem' field
     *
     * @param integer $Codedem
     *
     * @return Application_Model_Retrait_Row
     */
    public function setCodedem($Codedem)
    {
        $this->codedem = $Codedem;
        return $this;
    }

    /**
     * Get value of 'codedem' field
     *
     * @return integer
     */
    public function getCodedem()
    {
        return $this->codedem;
    }

    /**
     * Set value for 'cause' field
     *
     * @param string $Cause
     *
     * @return Application_Model_Retrait_Row
     */
    public function setCause($Cause)
    {
        $this->cause = $Cause;
        return $this;
    }

    /**
     * Get value of 'cause' field
     *
     * @return string
     */
    public function getCause()
    {
        return $this->cause;
    }

    /**
     * Set value for 'attestation_affectation' field
     *
     * @param string $AttestationAffectation
     *
     * @return Application_Model_Retrait_Row
     */
    public function setAttestationAffectation($AttestationAffectation)
    {
        $this->attestation_affectation = $AttestationAffectation;
        return $this;
    }

    /**
     * Get value of 'attestation_affectation' field
     *
     * @return string
     */
    public function getAttestationAffectation()
    {
        return $this->attestation_affectation;
    }

    /**
     * Get a row of Demande.
     *
     * @return Application_Model_Demande_Row
     */
    public function getDemandeRowByCodedem()
    {
        return $this->findParentRow('Application_Model_Demande_DbTable', 'codedem');
    }
    
    /**
     * Get the label that has been auto-detected by Zodeken
     *
     * @return string
     */
    public function getZodekenAutoLabel()
    {
        return $this->attestation_affectation;
    }
}
