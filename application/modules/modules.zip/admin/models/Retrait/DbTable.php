<?php

/**
 * Definition class for table retrait.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Retrait_DbTable extends Application_Model_Retrait_DbTable_Abstract
{
    // write your custom functions here
}