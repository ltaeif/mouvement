<?php

/**
 * Definition class for table detailconsultproc.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Detailconsultproc_DbTable extends Application_Model_Detailconsultproc_DbTable_Abstract
{
    // write your custom functions here
}