<?php

/**
 * Rowset definition class for table reorientation.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Reorientation_Rowset extends Application_Model_Reorientation_Rowset_Abstract
{
    // write your custom functions here
}
