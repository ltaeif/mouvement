<?php

/**
 * Row definition class for table authentif.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Authentif_Row extends Application_Model_Authentif_Row_Abstract
{
    // write your custom functions here
}
