<?php

/**
 * Row definition class for table chparcours.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Chparcours_Row extends Application_Model_Chparcours_Row_Abstract
{
    // write your custom functions here
}
