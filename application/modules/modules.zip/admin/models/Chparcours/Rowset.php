<?php

/**
 * Rowset definition class for table chparcours.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Chparcours_Rowset extends Application_Model_Chparcours_Rowset_Abstract
{
    // write your custom functions here
}
