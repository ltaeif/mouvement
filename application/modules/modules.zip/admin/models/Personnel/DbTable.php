<?php

/**
 * Definition class for table personnel.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Personnel_DbTable extends Application_Model_Personnel_DbTable_Abstract
{
    // write your custom functions here
}