<?php

/**
 * Row definition class for table personnel.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Personnel_Row extends Application_Model_Personnel_Row_Abstract
{
    // write your custom functions here
}
