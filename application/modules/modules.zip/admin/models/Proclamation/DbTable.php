<?php

/**
 * Definition class for table proclamation.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Proclamation_DbTable extends Application_Model_Proclamation_DbTable_Abstract
{
    // write your custom functions here
}