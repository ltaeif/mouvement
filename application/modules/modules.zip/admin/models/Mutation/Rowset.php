<?php

/**
 * Rowset definition class for table mutation.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Mutation_Rowset extends Application_Model_Mutation_Rowset_Abstract
{
    // write your custom functions here
}
