<?php

/**
 * Definition class for table mutation.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Mutation_DbTable extends Application_Model_Mutation_DbTable_Abstract
{
    // write your custom functions here
}