<?php

/**
 * Rowset definition class for table etudes.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Etudes_Rowset extends Application_Model_Etudes_Rowset_Abstract
{
    // write your custom functions here
}
