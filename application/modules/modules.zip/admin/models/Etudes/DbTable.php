<?php

/**
 * Definition class for table etudes.
 *
 * @package Admin
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Etudes_DbTable extends Application_Model_Etudes_DbTable_Abstract
{
    // write your custom functions here
}