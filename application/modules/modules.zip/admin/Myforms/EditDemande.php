﻿<?php

class Application_Myforms_EditDemande extends Zend_Form
{

   public function init()
    {	
    	
    	$auth = Zend_Auth::getInstance();
    	//var_dump($auth->getStorage()->read());
        $this->setMethod('post');

        $this->addElement(
            $this->createElement('hidden', 'codedem')
                
        );

       
        $this->addElement(
            $this->createElement('radio', 'etat')
                ->setLabel('Etat')
                ->setMultiOptions(array('En Attente' => 'En Attente','Refuser' => 'Refuser','Accepter' => 'Accepter'))
                ->setSeparator(" ")
                ->setValue("En Attente")
                ->addValidator(new Zend_Validate_InArray(array('haystack' => array('En Attente' => 'En Attente','Refuser' => 'Refuser','Accepter' => 'Accepter'))), true)
        );
		
		$this->addElement(
            $this->createElement('text', 'descriptif')
                ->setLabel('Descriptif')
                ->setAttrib("maxlength", 255)
                ->setAttrib("class", "input-xlarge ")
        		
                ->addValidator(new Zend_Validate_StringLength(array("max" => 255)), true)
                ->addFilter(new Zend_Filter_StringTrim())
        );

       $date= $this->createElement('text', 'date_demande')
        //->setLabel('Date Demande')
        ->setValue(date("Y-m-d H:i:s"))
        ->setAttrib("class", "input-medium hidden")
        
        ->addFilter(new Zend_Filter_StringTrim());
        
        $this->addElement($date);

        $this->addElement(
            $this->createElement('button', 'submit')
                ->setLabel('Save')
                ->setAttrib('class', 'btn btn-primary')
                ->setAttrib('type', 'submit')
        );

        parent::init();
    }
}

