<?php

/**
 * Definition class for table etudes.
 *
 * @package DefaultApplication_MyTables_Etudes_DbTable
 * @author Zodeken
 * @version $Id$
 */
class Application_Mytables_Etudes extends Application_Model_Etudes_DbTable_Abstract
{
    // write your custom functions here
}