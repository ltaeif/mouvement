﻿<?php
class Default_IndexController extends Zend_Controller_Action
{
	
	
	public function init()
	{
		/* Initialize action controller here */ 
		$this->_helper->layout()->setLayout("home"); 
		
	}
	
    public function indexAction()
    {
	
    }
    
    public function quituesAction(){
    	
    }
	
	
	public function homeAction(){
	
    }
	
	public function dashboardAction(){
	
    	
    }
}
