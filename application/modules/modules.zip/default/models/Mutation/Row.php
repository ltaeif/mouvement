<?php

/**
 * Row definition class for table mutation.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Mutation_Row extends Application_Model_Mutation_Row_Abstract
{
    // write your custom functions here
}
