<?php

/**
 * Rowset definition class for table proclamation.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Proclamation_Rowset extends Application_Model_Proclamation_Rowset_Abstract
{
    // write your custom functions here
}
