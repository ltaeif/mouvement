<?php

/**
 * Row definition class for table proclamation.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Proclamation_Row extends Application_Model_Proclamation_Row_Abstract
{
    // write your custom functions here
}
