<?php

/**
 * Definition class for table inscription.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Inscription_DbTable extends Application_Model_Inscription_DbTable_Abstract
{
    // write your custom functions here
}