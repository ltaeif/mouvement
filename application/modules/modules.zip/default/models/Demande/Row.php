<?php

/**
 * Row definition class for table demande.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Demande_Row extends Application_Model_Demande_Row_Abstract
{
    // write your custom functions here
}
