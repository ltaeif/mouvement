<?php

/**
 * Rowset definition class for table detailconsultproc.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Detailconsultproc_Rowset extends Application_Model_Detailconsultproc_Rowset_Abstract
{
    // write your custom functions here
}
