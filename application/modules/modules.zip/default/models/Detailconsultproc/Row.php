<?php

/**
 * Row definition class for table detailconsultproc.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Detailconsultproc_Row extends Application_Model_Detailconsultproc_Row_Abstract
{
    // write your custom functions here
}
