<?php

/**
 * Definition class for table detailconsultproc.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Detailconsultproc_DbTable extends Application_Model_Detailconsultproc_DbTable_Abstract
{
    // write your custom functions here
}