<?php

/**
 * Row definition class for table retrait.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Retrait_Row extends Application_Model_Retrait_Row_Abstract
{
    // write your custom functions here
}
