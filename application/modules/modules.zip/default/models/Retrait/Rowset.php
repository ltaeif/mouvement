<?php

/**
 * Rowset definition class for table retrait.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Retrait_Rowset extends Application_Model_Retrait_Rowset_Abstract
{
    // write your custom functions here
}
