<?php

/**
 * Rowset definition class for table files.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Files_Rowset extends Application_Model_Files_Rowset_Abstract
{
    // write your custom functions here
}
