<?php

/**
 * Definition class for table files.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Files_DbTable extends Application_Model_Files_DbTable_Abstract
{
    // write your custom functions here
}