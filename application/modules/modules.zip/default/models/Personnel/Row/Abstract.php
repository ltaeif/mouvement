<?php

/**
 * Row definition class for table personnel.
 *
 * Do NOT write anything in this file, it will be removed when you regenerated.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 * @method Application_Model_Personnel_Row setFromArray($data)
 *
 * @property integer $idpersonnel
 * @property string $nom
 * @property string $prenom
 * @property integer $cin
 * @property string $adresse
 * @property integer $numtel
 * @property string $Titre
 * @property string $organisme
 * @property string $codeetab
 * @property string $login
 */
abstract class Application_Model_Personnel_Row_Abstract extends Zend_Db_Table_Row_Abstract
{
    /**
     * Set value for 'idpersonnel' field
     *
     * @param integer $Idpersonnel
     *
     * @return Application_Model_Personnel_Row
     */
    public function setIdpersonnel($Idpersonnel)
    {
        $this->idpersonnel = $Idpersonnel;
        return $this;
    }

    /**
     * Get value of 'idpersonnel' field
     *
     * @return integer
     */
    public function getIdpersonnel()
    {
        return $this->idpersonnel;
    }

    /**
     * Set value for 'nom' field
     *
     * @param string $Nom
     *
     * @return Application_Model_Personnel_Row
     */
    public function setNom($Nom)
    {
        $this->nom = $Nom;
        return $this;
    }

    /**
     * Get value of 'nom' field
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set value for 'prenom' field
     *
     * @param string $Prenom
     *
     * @return Application_Model_Personnel_Row
     */
    public function setPrenom($Prenom)
    {
        $this->prenom = $Prenom;
        return $this;
    }

    /**
     * Get value of 'prenom' field
     *
     * @return string
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set value for 'cin' field
     *
     * @param integer $Cin
     *
     * @return Application_Model_Personnel_Row
     */
    public function setCin($Cin)
    {
        $this->cin = $Cin;
        return $this;
    }

    /**
     * Get value of 'cin' field
     *
     * @return integer
     */
    public function getCin()
    {
        return $this->cin;
    }

    /**
     * Set value for 'adresse' field
     *
     * @param string $Adresse
     *
     * @return Application_Model_Personnel_Row
     */
    public function setAdresse($Adresse)
    {
        $this->adresse = $Adresse;
        return $this;
    }

    /**
     * Get value of 'adresse' field
     *
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Set value for 'numtel' field
     *
     * @param integer $Numtel
     *
     * @return Application_Model_Personnel_Row
     */
    public function setNumtel($Numtel)
    {
        $this->numtel = $Numtel;
        return $this;
    }

    /**
     * Get value of 'numtel' field
     *
     * @return integer
     */
    public function getNumtel()
    {
        return $this->numtel;
    }

    /**
     * Set value for 'Titre' field
     *
     * @param string $Titre
     *
     * @return Application_Model_Personnel_Row
     */
    public function setTitre($Titre)
    {
        $this->Titre = $Titre;
        return $this;
    }

    /**
     * Get value of 'Titre' field
     *
     * @return string
     */
    public function getTitre()
    {
        return $this->Titre;
    }

    /**
     * Set value for 'organisme' field
     *
     * @param string $Organisme
     *
     * @return Application_Model_Personnel_Row
     */
    public function setOrganisme($Organisme)
    {
        $this->organisme = $Organisme;
        return $this;
    }

    /**
     * Get value of 'organisme' field
     *
     * @return string
     */
    public function getOrganisme()
    {
        return $this->organisme;
    }

    /**
     * Set value for 'codeetab' field
     *
     * @param string $Codeetab
     *
     * @return Application_Model_Personnel_Row
     */
    public function setCodeetab($Codeetab)
    {
        $this->codeetab = $Codeetab;
        return $this;
    }

    /**
     * Get value of 'codeetab' field
     *
     * @return string
     */
    public function getCodeetab()
    {
        return $this->codeetab;
    }

    /**
     * Set value for 'login' field
     *
     * @param string $Login
     *
     * @return Application_Model_Personnel_Row
     */
    public function setLogin($Login)
    {
        $this->login = $Login;
        return $this;
    }

    /**
     * Get value of 'login' field
     *
     * @return string
     */
    public function getLogin()
    {
        return $this->login;
    }

    /**
     * Get a row of Authentif.
     *
     * @return Application_Model_Authentif_Row
     */
    public function getAuthentifRowByLogin()
    {
        return $this->findParentRow('Application_Model_Authentif_DbTable', 'login');
    }

    /**
     * Get a list of rows of Proclamation.
     *
     * @return Application_Model_Proclamation_Rowset
     */
    public function getProclamationRowsByIdpersonnel()
    {
        return $this->findDependentRowset('Application_Model_Proclamation_DbTable', 'idpersonnel');
    }
    
    /**
     * Get the label that has been auto-detected by Zodeken
     *
     * @return string
     */
    public function getZodekenAutoLabel()
    {
        return $this->nom;
    }
}
