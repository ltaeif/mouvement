<?php

/**
 * Row definition class for table chparcours.
 *
 * Do NOT write anything in this file, it will be removed when you regenerated.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 * @method Application_Model_Chparcours_Row setFromArray($data)
 *
 * @property integer $codedem
 * @property integer $section_actuelle
 * @property string $niveau_actuelle
 * @property integer $section_demande
 * @property string $niveau_demande
 */
abstract class Application_Model_Chparcours_Row_Abstract extends Zend_Db_Table_Row_Abstract
{
    /**
     * Set value for 'codedem' field
     *
     * @param integer $Codedem
     *
     * @return Application_Model_Chparcours_Row
     */
    public function setCodedem($Codedem)
    {
        $this->codedem = $Codedem;
        return $this;
    }

    /**
     * Get value of 'codedem' field
     *
     * @return integer
     */
    public function getCodedem()
    {
        return $this->codedem;
    }

    /**
     * Set value for 'section_actuelle' field
     *
     * @param integer $SectionActuelle
     *
     * @return Application_Model_Chparcours_Row
     */
    public function setSectionActuelle($SectionActuelle)
    {
        $this->section_actuelle = $SectionActuelle;
        return $this;
    }

    /**
     * Get value of 'section_actuelle' field
     *
     * @return integer
     */
    public function getSectionActuelle()
    {
        return $this->section_actuelle;
    }

    /**
     * Set value for 'niveau_actuelle' field
     *
     * @param string $NiveauActuelle
     *
     * @return Application_Model_Chparcours_Row
     */
    public function setNiveauActuelle($NiveauActuelle)
    {
        $this->niveau_actuelle = $NiveauActuelle;
        return $this;
    }

    /**
     * Get value of 'niveau_actuelle' field
     *
     * @return string
     */
    public function getNiveauActuelle()
    {
        return $this->niveau_actuelle;
    }

    /**
     * Set value for 'section_demande' field
     *
     * @param integer $SectionDemande
     *
     * @return Application_Model_Chparcours_Row
     */
    public function setSectionDemande($SectionDemande)
    {
        $this->section_demande = $SectionDemande;
        return $this;
    }

    /**
     * Get value of 'section_demande' field
     *
     * @return integer
     */
    public function getSectionDemande()
    {
        return $this->section_demande;
    }

    /**
     * Set value for 'niveau_demande' field
     *
     * @param string $NiveauDemande
     *
     * @return Application_Model_Chparcours_Row
     */
    public function setNiveauDemande($NiveauDemande)
    {
        $this->niveau_demande = $NiveauDemande;
        return $this;
    }

    /**
     * Get value of 'niveau_demande' field
     *
     * @return string
     */
    public function getNiveauDemande()
    {
        return $this->niveau_demande;
    }

    /**
     * Get a row of Demande.
     *
     * @return Application_Model_Demande_Row
     */
    public function getDemandeRowByCodedem()
    {
        return $this->findParentRow('Application_Model_Demande_DbTable', 'codedem');
    }

    /**
     * Get a row of Parcours.
     *
     * @return Application_Model_Parcours_Row
     */
    public function getParcoursRowBySectionActuelle()
    {
        return $this->findParentRow('Application_Model_Parcours_DbTable', 'section_actuelle');
    }

    /**
     * Get a row of Parcours.
     *
     * @return Application_Model_Parcours_Row
     */
    public function getParcoursRowBySectionDemande()
    {
        return $this->findParentRow('Application_Model_Parcours_DbTable', 'section_demande');
    }
    
    /**
     * Get the label that has been auto-detected by Zodeken
     *
     * @return string
     */
    public function getZodekenAutoLabel()
    {
        return $this->codedem;
    }
}
