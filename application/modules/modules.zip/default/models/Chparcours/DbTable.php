<?php

/**
 * Definition class for table chparcours.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Chparcours_DbTable extends Application_Model_Chparcours_DbTable_Abstract
{
    // write your custom functions here
}