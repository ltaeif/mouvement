<?php

/**
 * Rowset definition class for table parcours.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Parcours_Rowset extends Application_Model_Parcours_Rowset_Abstract
{
    // write your custom functions here
}
