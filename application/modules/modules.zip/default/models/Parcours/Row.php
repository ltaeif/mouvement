<?php

/**
 * Row definition class for table parcours.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 */
class Application_Model_Parcours_Row extends Application_Model_Parcours_Row_Abstract
{
    // write your custom functions here
}
