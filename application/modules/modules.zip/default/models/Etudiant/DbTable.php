<?php

/**
 * Definition class for table etudiant.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Etudiant_DbTable extends Application_Model_Etudiant_DbTable_Abstract
{
    // write your custom functions here
}