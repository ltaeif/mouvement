<?php

/**
 * Definition class for table authentif.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_Authentif_DbTable extends Application_Model_Authentif_DbTable_Abstract
{
    // write your custom functions here
}