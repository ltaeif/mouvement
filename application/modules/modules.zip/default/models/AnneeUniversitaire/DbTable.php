<?php

/**
 * Definition class for table annee_universitaire.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 */
class Application_Model_AnneeUniversitaire_DbTable extends Application_Model_AnneeUniversitaire_DbTable_Abstract
{
    // write your custom functions here
}