<?php

/**
 * Row definition class for table etablissement.
 *
 * Do NOT write anything in this file, it will be removed when you regenerated.
 *
 * @package Default
 * @author Zodeken
 * @version $Id$
 *
 * @method Application_Model_Etablissement_Row setFromArray($data)
 *
 * @property string $codeetab
 * @property string $denomination
 * @property string $adresse
 * @property integer $numtel
 */
abstract class Application_Model_Etablissement_Row_Abstract extends Zend_Db_Table_Row_Abstract
{
    /**
     * Set value for 'codeetab' field
     *
     * @param string $Codeetab
     *
     * @return Application_Model_Etablissement_Row
     */
    public function setCodeetab($Codeetab)
    {
        $this->codeetab = $Codeetab;
        return $this;
    }

    /**
     * Get value of 'codeetab' field
     *
     * @return string
     */
    public function getCodeetab()
    {
        return $this->codeetab;
    }

    /**
     * Set value for 'denomination' field
     *
     * @param string $Denomination
     *
     * @return Application_Model_Etablissement_Row
     */
    public function setDenomination($Denomination)
    {
        $this->denomination = $Denomination;
        return $this;
    }

    /**
     * Get value of 'denomination' field
     *
     * @return string
     */
    public function getDenomination()
    {
        return $this->denomination;
    }

    /**
     * Set value for 'adresse' field
     *
     * @param string $Adresse
     *
     * @return Application_Model_Etablissement_Row
     */
    public function setAdresse($Adresse)
    {
        $this->adresse = $Adresse;
        return $this;
    }

    /**
     * Get value of 'adresse' field
     *
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Set value for 'numtel' field
     *
     * @param integer $Numtel
     *
     * @return Application_Model_Etablissement_Row
     */
    public function setNumtel($Numtel)
    {
        $this->numtel = $Numtel;
        return $this;
    }

    /**
     * Get value of 'numtel' field
     *
     * @return integer
     */
    public function getNumtel()
    {
        return $this->numtel;
    }

    /**
     * Get a list of rows of Etudiant.
     *
     * @return Application_Model_Etudiant_Rowset
     */
    public function getEtudiantRowsByCodeetab()
    {
        return $this->findDependentRowset('Application_Model_Etudiant_DbTable', 'codeetab');
    }

    /**
     * Get a list of rows of Mutation.
     *
     * @return Application_Model_Mutation_Rowset
     */
    public function getMutationRowsByEtablissementDemande()
    {
        return $this->findDependentRowset('Application_Model_Mutation_DbTable', 'etablissement_demande');
    }

    /**
     * Get a list of rows of Parcours.
     *
     * @return Application_Model_Parcours_Rowset
     */
    public function getParcoursRowsByCodeetab()
    {
        return $this->findDependentRowset('Application_Model_Parcours_DbTable', 'codeetab');
    }

    /**
     * Get a list of rows of Reorientation.
     *
     * @return Application_Model_Reorientation_Rowset
     */
    public function getReorientationRowsByEtablissementDemande()
    {
        return $this->findDependentRowset('Application_Model_Reorientation_DbTable', 'etablissement_demande');
    }
    
    /**
     * Get the label that has been auto-detected by Zodeken
     *
     * @return string
     */
    public function getZodekenAutoLabel()
    {
        return $this->codeetab;
    }
}
